// Fill out your copyright notice in the Description page of Project Settings.


#include "HakExperienceDefinition.h"

UHakExperienceDefinition::UHakExperienceDefinition(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
}
