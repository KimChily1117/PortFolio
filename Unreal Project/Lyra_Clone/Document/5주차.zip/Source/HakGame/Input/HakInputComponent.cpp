// Fill out your copyright notice in the Description page of Project Settings.


#include "HakInputComponent.h"

UHakInputComponent::UHakInputComponent(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
}
