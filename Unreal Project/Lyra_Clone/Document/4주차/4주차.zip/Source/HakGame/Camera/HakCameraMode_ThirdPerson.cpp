// Fill out your copyright notice in the Description page of Project Settings.


#include "HakCameraMode_ThirdPerson.h"

UHakCameraMode_ThirdPerson::UHakCameraMode_ThirdPerson(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{}