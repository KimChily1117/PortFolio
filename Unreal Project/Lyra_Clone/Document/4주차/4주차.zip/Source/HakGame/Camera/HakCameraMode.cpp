#include "HakCameraMode.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(HakCameraMode)

UHakCameraMode::UHakCameraMode(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{}

UHakCameraModeStack::UHakCameraModeStack(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{}