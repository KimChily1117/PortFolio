// Fill out your copyright notice in the Description page of Project Settings.

#include "HakLogChannels.h"

DEFINE_LOG_CATEGORY(LogHak);