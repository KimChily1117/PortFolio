// Fill out your copyright notice in the Description page of Project Settings.


#include "HakCombatSet.h"

UHakCombatSet::UHakCombatSet() : Super() , BaseHeal(0.0f)
{
}
