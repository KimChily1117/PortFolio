// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "HakActivatableWidget.h"
#include "HakHUDLayout.generated.h"

/**
 * 
 */
UCLASS()
class HAKGAME_API UHakHUDLayout : public UHakActivatableWidget
{
	GENERATED_BODY()
	
};
