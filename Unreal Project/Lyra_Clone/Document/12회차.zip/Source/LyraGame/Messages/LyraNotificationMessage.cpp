// Copyright Epic Games, Inc. All Rights Reserved.

#include "LyraNotificationMessage.h"


#include UE_INLINE_GENERATED_CPP_BY_NAME(LyraNotificationMessage)

UE_DEFINE_GAMEPLAY_TAG(TAG_Lyra_AddNotification_Message, "Lyra.AddNotification.Message");

