﻿# Lyra

The Lyra project is to provide a bootstrapping game for Unreal Engine.  Lyra is intended to be a living sample that shows how we build scalable games around the engines core technology.