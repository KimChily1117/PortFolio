// Copyright Epic Games, Inc. All Rights Reserved.

#include "LyraNumberPopComponent.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(LyraNumberPopComponent)

ULyraNumberPopComponent::ULyraNumberPopComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

