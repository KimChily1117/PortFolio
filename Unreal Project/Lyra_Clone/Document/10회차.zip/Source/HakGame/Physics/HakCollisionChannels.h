#pragma once

#include "CoreMinimal.h"
#include "Engine/EngineTypes.h"

/** Weapon�� Collision Trace Channel */
#define Hak_TraceChannel_Weapon				ECC_GameTraceChannel2